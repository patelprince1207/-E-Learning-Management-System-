<?php
// =======================
// COURSE DETAILS (ADD YOUR VALUES HERE)
// =======================
$course_name = "Full Stack Development";  // change dynamically later
$amount = "1666";                         // course price

// =======================
// PAYMENT DETAILS
// =======================
$payee_upi = '9726367803@ybl';
$payee_name = 'jenret';
$note = $course_name . " Payment";
$order_id = 'ORD' . time();               // Auto generated unique order ID

// =======================
// BUILD UPI PAYMENT URL
// =======================
$upi_uri = "upi://pay?pa=" . urlencode($payee_upi) .
           "&pn=" . urlencode($payee_name) .
           "&am=" . urlencode($amount) .
           "&tn=" . urlencode($note) .
           "&tr=" . urlencode($order_id);

// =======================
// QR CODE SAVE DIRECTORY
// =======================
$qrcodes_dir = __DIR__ . '/qrcodes';
if (!is_dir($qrcodes_dir)) mkdir($qrcodes_dir, 0755, true);

$filename = "QR_{$order_id}_" . substr(md5($upi_uri),0,8) . ".png";
$filepath = $qrcodes_dir . '/' . $filename;
$webpath  = 'qrcodes/' . $filename;

// =======================
// GENERATE THE QR CODE
// =======================
$generated_file_url = '';
if (extension_loaded('gd') && file_exists(__DIR__.'/phpqrcode/qrlib.php')) {
    include_once __DIR__.'/phpqrcode/qrlib.php';
    QRcode::png($upi_uri, $filepath, 'L', 8, 2);
    if (file_exists($filepath)) {
        $generated_file_url = $webpath;
    }
} else {
    // fallback: online generator
    $generated_file_url = "https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=" . rawurlencode($upi_uri);
}
?>

<!-- ======================= -->
<!-- DISPLAY PAYMENT DETAILS -->
<!-- ======================= -->
<div style="text-align:center; margin-top:20px; font-family:Arial;">
    
    <h2><?php echo $course_name; ?></h2>

    <p style="font-size:18px;">
        <strong>Price:</strong> ₹<?php echo $amount; ?><br>
        <strong>Order ID:</strong> <?php echo $order_id; ?>
    </p>

    <div style="display:flex; justify-content:center; align-items:center; margin-top:20px;">
        <img src="<?php echo htmlspecialchars($generated_file_url); ?>" 
            alt="UPI QR"
            style="border:1px solid black; padding:5px; width:320px;">
    </div>
</div>
